#ifndef ATLAS_CSNKB_H
   #define ATLAS_CSNKB_H
   #define ATL_CSNKB 0
#endif
