#ifndef SXOVER_H
#define SXOVER_H

#define ATL_3NB 48
#define NN_MNK_M 1600
#define NN_MNK_N 1600
#define NN_MNK_MN 2560
#define NN_MNK_K 1600
#define NN_MNK_GE 1000
#define NT_MNK_M 1600
#define NT_MNK_N 1600
#define NT_MNK_MN 2560
#define NT_MNK_K 3600
#define NT_MNK_GE 1000
#define TN_MNK_M 1600
#define TN_MNK_N 1600
#define TN_MNK_MN 2560
#define TN_MNK_K 1600
#define TN_MNK_GE 1000
#define TT_MNK_M 1600
#define TT_MNK_N 1600
#define TT_MNK_MN 2560
#define TT_MNK_K 3600
#define TT_MNK_GE 1000

#endif
