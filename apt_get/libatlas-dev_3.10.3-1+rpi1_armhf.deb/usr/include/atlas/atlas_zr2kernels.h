/*
 * This file generated on line 754 of /atlas-3.10.3/build/atlas-base/../..//tune/blas/ger/r2hgen.c
 */
#ifndef ATLAS_ZR2KERNELS_H
   #define ATLAS_ZR2KERNELS_H

void ATL_zger2k__1
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_zger2k__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_zger2k__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_zger2k__1
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);


#endif /* end guard around atlas_zr2kernels.h */
