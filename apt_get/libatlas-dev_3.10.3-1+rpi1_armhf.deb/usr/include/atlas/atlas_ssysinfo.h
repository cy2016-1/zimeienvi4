#ifndef ATL_SSYSINFO_H
   #define ATL_SSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 4096
#define ATL_fplat  1
#define ATL_lbnreg 4
#define ATL_mmnreg 128
#define ATL_nkflop 140490

#endif
