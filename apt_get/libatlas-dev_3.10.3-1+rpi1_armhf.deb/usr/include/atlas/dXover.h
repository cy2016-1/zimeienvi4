#ifndef DXOVER_H
#define DXOVER_H

#define ATL_3NB 108
#define NN_MNK_M 311364
#define NN_MNK_N 3600
#define NN_MNK_MN 390096
#define NN_MNK_K 8100
#define NN_MNK_GE 13824
#define NT_MNK_M 51984
#define NT_MNK_N 51984
#define NT_MNK_MN 12960
#define NT_MNK_K 3600
#define NT_MNK_GE 54872
#define TN_MNK_M 3600
#define TN_MNK_N 3600
#define TN_MNK_MN 12960
#define TN_MNK_K 8100
#define TN_MNK_GE 1000
#define TT_MNK_M 3600
#define TT_MNK_N 608400
#define TT_MNK_MN 847584
#define TT_MNK_K 8100
#define TT_MNK_GE 1000

#endif
